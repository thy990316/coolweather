db包      用于存放数据库模型相关的代码
gson包    用于存放GSON模型相关的代码
service包 用于存放服务相关的代码
util包    用于存放工具相关的代码

app/build.gradle
LitePal   用于对数据库进行操作
OkHttp    用于进行网络请求
GSON      用于解析JSON数据
Glide     用于加载和展示图片。
